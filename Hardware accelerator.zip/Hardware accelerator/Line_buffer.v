module line_buffer#(
    parameter DATA_WIDTH = 8,
    parameter W_IN = 256
)
(
    input data[]

);

reg [7:0] LB [W_IN-1:0];


endmodule