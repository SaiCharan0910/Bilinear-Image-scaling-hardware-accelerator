from PIL import Image
import os

def generate_grayscale_coe(image_path, output_coe_path, target_size=(128, 128)):
    """
    Reads an image, converts it to grayscale, resizes it, 
    and outputs a Xilinx .coe file.
    """
    if not os.path.exists(image_path):
        print(f"Error: Could not find image at {image_path}")
        return

    # 1. Open the image, convert to Grayscale ('L' mode is 8-bit pixels)
    img = Image.open(image_path).convert('L')
    
    # 2. Resize to fit FPGA BRAM limits
    img = img.resize(target_size)
    print(f"Image resized to {target_size[0]}x{target_size[1]}.")
    
    # 3. Extract pixel data as a flat list of integers (0-255)
    pixels = list(img.getdata())
    total_pixels = len(pixels)
    
    # 4. Write to .coe file
    with open(output_coe_path, 'w') as f:
        # Write Vivado COE headers
        f.write("memory_initialization_radix=16;\n")
        f.write("memory_initialization_vector=\n")
        
        # Write each pixel as a 2-character hex string (e.g., '0F', 'A5')
        for i, pixel_val in enumerate(pixels):
            # Format integer to 2-digit uppercase hex
            hex_str = f"{pixel_val:02X}" 
            
            if i == total_pixels - 1:
                f.write(f"{hex_str};\n") # Last item gets a semicolon
            else:
                f.write(f"{hex_str},\n") # All others get a comma

    print(f"Success! {total_pixels} pixels written to '{output_coe_path}'.")

# --- Run the Script ---
# Change 'my_test_image.jpg' to the name of your actual image file
generate_grayscale_coe('Grayscale.png', 'grayscale_image.coe', target_size=(128, 128))